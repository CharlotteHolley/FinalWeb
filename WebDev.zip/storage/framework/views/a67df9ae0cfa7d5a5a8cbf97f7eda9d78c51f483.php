

<?php $__env->startSection('title'); ?>
    Contact us
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    Contact page example
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>