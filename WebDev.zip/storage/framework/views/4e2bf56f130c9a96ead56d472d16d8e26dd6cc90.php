

<?php $__env->startSection('title'); ?>
    Deadlines
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <?php echo e($deadline->subject); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<p>
<?php echo e($deadline->description); ?>

</p>
<a href="/deadlines/<?php echo e($deadline->id); ?>/edit">Edit</a>
<br />
<br />


<?php if($deadline->tasks->count()): ?>
<div>
    <?php $__currentLoopData = $deadline->tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form method="POST" action="/completed-tasks/<?php echo e($task->id); ?>">
        
        
       <?php if($task->completed): ?>
            <?php echo e(method_field('DELETE')); ?>

       <?php endif; ?> 
            
            
            <?php echo e(csrf_field()); ?>

            
            <label class="checkbox" for="completed" <?php echo e($task->completed ? 'is-complete' : ''); ?>>
            <input type="checkbox" name="completed" onChange="this.form.submit()" <?php echo e($task->completed ? 'checked' : ''); ?>>
            <?php echo e($task->description); ?>

        </form>
        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>

<br />
<hr>
<br />

<form method="POST" action=" <?php echo e($deadline->id); ?>/tasks">
<?php echo e(csrf_field()); ?>

    <div class="field">
        <label class="label" for="description"> New  Task </label>
    
        <div class="control">
            <input type="text" class="input" name="description" placeholder="New Task" required>
        </div>
    </div>
    
    <div class="field">
        <div class="control">
            <button type="submit" class="button is-link"> Add Task </button>
        </div>
    </div>
    <?php echo $__env->make('errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</form>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>