

<?php $__env->startSection('title'); ?>
    Deadlines
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    Edit Deadline
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<form method="POST" action="/deadlines/<?php echo e($deadline->id); ?>">

<?php echo e(method_field('PATCH')); ?>


<?php echo e(csrf_field()); ?>


<div class="field">
    <label class="label" for="title"> Subject Name </label>
    
<div class="control">
    <input type="text" class="input" name="subject" placeholder="Subject name" required value="<?php echo e($deadline->subject); ?>">
</div>
</div>
<br />
<div class="field">
    <label class="label" for="desctitle">Description</label>
<div class="control">
    <textarea name="description" class="textarea" required><?php echo e($deadline->description); ?></textarea>
</div>
</div>
<br />
<div class="field">
<div class="control">
    <button type="submit" class="button is-link">Update deadline</button>
</div>
</div>

</form>

<form method="POST" action="/deadlines/<?php echo e($deadline->id); ?>">

<?php echo e(method_field('DELETE')); ?>


<?php echo e(csrf_field()); ?>


<div class="field">
<div class="control">
    <button type="submit" class="button">Delete deadline</button>
</div>
</div>

</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>