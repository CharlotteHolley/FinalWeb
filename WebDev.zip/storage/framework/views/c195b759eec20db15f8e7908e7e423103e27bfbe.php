

<?php $__env->startSection('title'); ?>
    Deadlines
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    My Deadlines
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<a href="/deadlines/create">Create a new deadline</a>

<ul>
    <?php $__currentLoopData = $deadlines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deadline): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li> <?php echo e($deadline->subject); ?> </li>
    <p> <?php echo e($deadline->description); ?> </p>
    <br />
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ol>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>