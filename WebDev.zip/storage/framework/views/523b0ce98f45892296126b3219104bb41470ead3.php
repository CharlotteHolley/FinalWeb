

<?php $__env->startSection('title'); ?>
    Deadlines
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    Create new deadline
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<a href="/deadlines"> Go back</a>

<form method="POST" action="/deadlines">

<?php echo e(csrf_field()); ?>


<div>
<input type="text" name="subject" placeholder="Subject name" value="<?php echo e(old('subject')); ?>" required> <br />
<div>
</br>
<textarea name="description" placeholder="Description" required><?php echo e(old('description')); ?></textarea>
</div>
<button type="submit"> Create deadline </button>
</div>

<?php echo $__env->make('errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>