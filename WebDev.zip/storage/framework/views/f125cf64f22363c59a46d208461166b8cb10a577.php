<?php $__env->startComponent('mail::message'); ?>
# New deadline created: <?php echo e($deadline->subject); ?>


<?php echo e($deadline->description); ?>


<?php $__env->startComponent('mail::button', ['url' => url('/deadlines/' . $deadline->id )]); ?>

View Deadline
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
